package i.impl.good;

public interface IAgeAware {
    int getRecommendedAge();
}
