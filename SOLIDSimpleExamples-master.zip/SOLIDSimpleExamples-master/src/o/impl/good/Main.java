package o.impl.good;

public class Main {

    public void draw(Vehicle vehicle) {
        vehicle.draw();
    }

}
