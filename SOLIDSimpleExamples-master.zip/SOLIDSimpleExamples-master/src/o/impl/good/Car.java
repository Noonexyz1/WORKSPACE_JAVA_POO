package o.impl.good;

public class Car extends Vehicle {

    @Override public void draw() {
// Draw the car
    }
}
