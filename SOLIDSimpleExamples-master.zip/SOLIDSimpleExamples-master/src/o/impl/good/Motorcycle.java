package o.impl.good;

public class Motorcycle extends Vehicle {

    @Override public void draw() {
// Draw the motorbike
    }
}
