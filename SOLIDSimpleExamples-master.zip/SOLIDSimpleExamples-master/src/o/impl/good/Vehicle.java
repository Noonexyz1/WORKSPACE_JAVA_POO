package o.impl.good;

public abstract class Vehicle {

    public abstract void draw();

}
