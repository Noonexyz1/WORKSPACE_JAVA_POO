package o.impl.bad;

public enum VehicleType {
    CAR,
    MOTORBIKE
}
