package o.impl.bad;

public class Vehicle {

    public VehicleType getType() {

        return null;
    }
}
