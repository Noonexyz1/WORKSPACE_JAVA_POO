package l.impl.good;

public class Square  implements IFourSidedFigured {


    @Override
    public int getWidth() {
        return 0;
    }

    @Override
    public int getHeight() {
        return 0;
    }

    @Override
    public int calculateArea() {
        return 0;
    }
}
