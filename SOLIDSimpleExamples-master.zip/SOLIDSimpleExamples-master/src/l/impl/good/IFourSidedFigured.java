package l.impl.good;

public interface IFourSidedFigured {
    int getWidth();
    int getHeight();
    int calculateArea();
}
