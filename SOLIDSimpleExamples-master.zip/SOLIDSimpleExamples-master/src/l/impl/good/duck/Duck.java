package l.impl.good.duck;

public class Duck {

    public String quack() {
        return "Quack";
    }
}
