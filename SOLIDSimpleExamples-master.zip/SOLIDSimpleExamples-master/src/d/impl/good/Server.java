package d.impl.good;

public class Server implements IPersistence {

    @Override
    public void save(Shopping shopping) {
// Saves data in a server
    }
}
