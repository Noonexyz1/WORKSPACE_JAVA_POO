package d.impl.good;

public class Shopping {
}
