package d.impl.good;

public interface  IPaymentMethod {
    void pay(Shopping shopping);
}

