package d.impl.good;

public class CreditCard implements IPaymentMethod {

    @Override
    public void pay(Shopping shopping){
// Performs payment using a credit card
    }
}
