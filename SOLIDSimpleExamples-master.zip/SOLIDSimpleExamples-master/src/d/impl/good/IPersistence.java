package d.impl.good;

public interface IPersistence {
    void save(Shopping shopping);
}

