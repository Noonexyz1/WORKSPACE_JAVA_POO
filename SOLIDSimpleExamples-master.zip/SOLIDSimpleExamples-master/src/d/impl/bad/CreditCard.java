package d.impl.bad;

public class CreditCard {

    public void pay(Shopping shopping){
// Performs payment using a credit card
    }
}
