package d.impl.bad;

public class Shopping {
}
