package d.impl.bad;

public class SqlDatabase {
    public void save(Shopping shopping){
// Saves data in SQL database
    }
}
