package s.impl.bad;

public class Car {

}
