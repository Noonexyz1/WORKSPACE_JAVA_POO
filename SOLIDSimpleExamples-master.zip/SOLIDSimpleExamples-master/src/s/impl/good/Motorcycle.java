package s.impl.good;

public class Motorcycle  implements Vehicle{
    @Override
    public int calculateVelocity() {
        return 60;
    }
}
