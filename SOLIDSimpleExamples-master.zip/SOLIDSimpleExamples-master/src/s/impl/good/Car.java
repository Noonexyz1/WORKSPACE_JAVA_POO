package s.impl.good;

public class Car implements Vehicle{
    @Override
    public int calculateVelocity() {
        return 50;
    }
}
