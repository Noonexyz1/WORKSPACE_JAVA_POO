package s.impl.good;

public interface Vehicle {

    int calculateVelocity();

}
